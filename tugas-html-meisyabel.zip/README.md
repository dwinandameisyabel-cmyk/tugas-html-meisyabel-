
# Tugas HTML - Profil Penulis Favorit

Repositori ini berisi tugas HTML untuk menampilkan profil penulis sastra favorit.

## Panduan
1. File utama adalah `index.html`.
2. Buka file tersebut di browser untuk melihat hasilnya.
3. Upload isi repositori ini ke GitHub agar bisa ditampilkan melalui GitHub Pages.

## Identitas
- **Nama:** Meisyabel  
- **NPM:** A1B025134  
- **Kakak Pembimbing:** Reksi Hendra Pratama (G1A022032)  
- **Prodi:** Pendidikan Bahasa Inggris
