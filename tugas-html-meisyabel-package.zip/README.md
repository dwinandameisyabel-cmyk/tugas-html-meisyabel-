# tugas-html-meisyabel

Repository ini berisi file tugas HTML untuk tugas profil penulis dan dokumentasi.

## Isi repositori
- `profile-tere-liye-ol.html` : Halaman profil Tere Liye (menggunakan ordered list untuk daftar karya).
- `Laporan_Tugas_HTML_Meisyabel.docx` : Contoh laporan tugas (judul, identitas, langkah upload GitHub, hasil).
- `profile-tere-liye.pdf` : PDF dokumentasi tampilan halaman (versi teks).
- `README.md` : Penjelasan singkat dan panduan melihat hasil di GitHub Pages.

## Cara melihat di GitHub Pages
1. Upload semua file ke repository GitHub dengan nama `tugas-html-meisyabel`.
2. Masuk ke **Settings → Pages**, pilih branch `main` (atau `master`) dan folder `/ (root)`, lalu klik Save.
3. Tunggu beberapa menit, lalu akses halaman di: `https://<username>.github.io/tugas-html-meisyabel/`

## Panduan singkat mengisi formulir (jika ada)
- Ikuti instruksi pada halaman HTML jika terdapat formulir. Isikan data yang diminta, lalu klik Submit.
- Jika form tidak dihubungkan ke server, hasil tidak akan tersimpan secara online.
